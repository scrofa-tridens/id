function loadImages(source, target, urls) {
	if(!source.colorActive && urls.length > 0) {
		var family = source.parentNode.children;
		for(var i =  0; i < family.length; i++) {
			family[i].colorActive = false;
			family[i].className = family[i].className.replace(/\s*\bproduct_colors_active\b/g, '');
		}
		source.colorActive = true;
		source.className += ' product_colors_active';
		target.innerHTML = '';
		var img = target.appendChild(document.createElement('img'));
			img.src = urls[0]['image'];
			img.alt = img.title = urls[0]['title'];
			img.className = 'border_1';
		var list = target.appendChild(document.createElement('div'));
			list.className = 'product_image_list';
		function thumbHandler(img, urls, i) {
			return function(e) {
				img.src = urls[i]['image'];
			}
		}
		for(var i = 0; i < urls.length; i++) {
			var thumb = list.appendChild(document.createElement('a'));
				thumb.href = 'javascript:void(0)';
				thumb.style = 'background-image: url(\'' + urls[i]['thumb'] + '\');';
				thumb.addEventListener("click", thumbHandler(img, urls, i), false);
				list.appendChild(document.createTextNode(' '));
		}
	}
}
function showDelivery() {
	var p = document.getElementById('delivery_pickup_fieldset');
	var c = document.getElementById('delivery_courier_fieldset');
	p.style.display = document.getElementById("delivery_pickup").checked ? '' : 'none';
	c.style.display = document.getElementById("delivery_courier").checked ? '' : 'none';
}
