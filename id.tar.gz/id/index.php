<?php
include 'config.php';
$lengths = array(
	'fio' => 200,
	'phone' => 45,
	'email' => 254,
	'comment' => 2000,
	'advanced' => 2000,
	'latin' => 2000,
	'street' => 200,
	'house' => 45,
	'entrance' => 45,
	'intercom' => 45,
	'floor' => 45,
	'flat' => 45,
	'building' => 45
);
function empty2null($variable) {
	return (trim($variable) == '') ? NULL : $variable;
}
$conn = new PDO('mysql:host=' . $db['host'] . ';dbname=' . $db['name'] . ';charset=utf8', $db['username'], $db['password']);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
switch(trim($_POST['form'])) {
	case '' :
		$status = 0;
		break;
	case 'test' :
		$status = 1;
		$test_required = array('email', 'info', 'delivery');
		switch(trim($_POST['delivery'])) {
			case '' :
				break;
			case 'courier' :
				array_push($test_required, 'street', 'house');
				$delivery = 'Курьером';
				$latin = $_POST['latin_c'];
				break;
			case 'pickup' :
				array_push($test_required, 'point');
				$delivery = 'Самовывоз';
				$latin = $_POST['latin_p'];
				break;
		}
		$test_missing = array();
		foreach($test_required as $field) {
			if(trim($_POST[$field] == '')) {
				$test_missing[$field] = ' class="border_red"';
			}
		}
		if(count($test_missing) > 0) {
			$status = 2;
			break;
		}
		if($status == 1) {
			$post = array_map('empty2null', $_POST);
			$post['delivery'] = $delivery;
			$post['latin'] = $latin;
			$post['point'] = $_POST['delivery'] == 'pickup' ? $_POST['point'] : NULL;
			$post['rerum'] = $_POST['rerum'] == NULL ? 0 : 1;
			foreach($lengths as $key => $value) {
				$post[$key] = substr($post[$key], 0, $value);
			}
			$sql_fields = '`fio`, `phone`, `email`, `comment`, `advanced`, `vadis`, `rerum`, `delivery`, `points_id`, `latin`';
			$sql_values = ':fio, :phone, :email, :comment, :advanced, :vadis, :rerum, :delivery, :points_id, :latin';
			$fields = array(
				':fio' => $post['fio'],
				':phone' => $post['phone'],
				':email' => $post['email'],
				':comment' => $post['info'],
				':advanced' => $post['advanced'],
				':vadis' => $post['vadis'],
				':rerum' => $post['rerum'],
				':delivery' => $post['delivery'],
				':points_id' => $post['point'],
				':latin' => $post['latin']
			);
			if($_POST['delivery'] == 'courier') {
				$sql_fields .= ', `street`, `house`, `entrance`, `intercom`, `floor`, `flat`, `building`';
				$sql_values .= ', :street, :house, :entrance, :intercom, :floor, :flat, :building';
				$fields_new = array(
					':street' => $post['street'],
					':house' => $post['house'],
					':entrance' => $post['entrance'],
					':intercom' => $post['intercom'],
					':floor' => $post['floor'],
					':flat' => $post['flat'],
					':building' => $post['building']
				);
				foreach($fields_new as $key => $value) {
					$fields[$key] = $value;
				}
			}
			$stmt_o = $conn->prepare("INSERT INTO `orders` (" . $sql_fields . ") VALUES (" . $sql_values . ")");
			$stmt_o->execute($fields);
		}
		break;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<title>Тестовое задание фронт-энд 2. Задание 2.</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link href="/css/style.css" rel="stylesheet" type="text/css" />
<link href="/css/layout.css" rel="stylesheet" type="text/css" />
<script src="/scripts/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="/scripts/productimages.js" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		<?php
		switch(trim($_POST['delivery'])) {
			case '' : case 'courier' :
				echo 'document.getElementById("delivery_courier_fieldset").checked = true;';
				break;
			case 'pickup' :
				echo 'document.getElementById("delivery_pickup_fieldset").checked = true;';
				break;
		}
		?>
		showDelivery();
	});
</script>
</head>
<body>
	<div id="wrapper">
		<header id="header">
			<div id="header_content">
				<a id="brand" href="/">
					<span id="sitename">Naushniki</span>
					<span id="slogan">Магазин беспроводных наушников</span>
				</a>
				<a class="phone" href="tel:+79999999999">
					+ 7(999) 999-99-99
					<span class="phone_text">Ждём вашего звонка с 10:00 до 23:00</span>
				</a>
				<div id="header_text">Возможный текст в шапке. Шапка тянется по высоте.</div>
			</div>
			<nav class="menu_main">
				<?php
				$menudata = $conn->query("SELECT * FROM `pages` ORDER BY `sort`");
				$level = 0;
				foreach($menudata as $row) {
					if($row['level'] > 0) {
						if($row['level'] > $level) {
							$level++;
							echo '<ul>';
						} elseif($row['level'] <= $level) {
							while($row['level'] < $level) {
								$level--;
								echo '</li></ul>';
							}
							echo '</li>';
						}
						if(($row['flags'] >> 1) & 1) {
							echo '<li class="linebreak">Поскольку в ul нельзя br</li>';
						}
						echo '<li><a href="' . $row['url'] . '"' . ($row['description'] ? ' title="' . $row['description'] . '"' : '') . '>' . $row['title'] . '</a>';
					}
				}
				while($level > 0) {
					$level--;
					echo '</li></ul>';
				}
				?>
			</nav>
			<a id="logo" href="/"></a>
		</header>
		<main>
			<div class="product_summary clearfix margin_bottom">
				<div id="product_image_1" class="product_image border_1"></div>
				<h1>Beats PowerBeats 2 (черно-красный)</h1>
				<form class="product_buy" method="post" action="index.php">
					<fieldset>
						<input type="hidden" name="form" value="buy" />
						<div class="price">3690 руб.</div>
						<div class="price_old">4790 руб.</div>
						<input type="submit" value="Купить" />
					</fieldset>
				</form>
				<div class="product_minidescription columns">
					<div class="block margin_bottom">
						<h3>Доступные цвета</h3>
						<!--
							Цвета и картинки должны браться из базы, но реализовывать не стал,
							поскольку тут всё просто и очевидно; проще, чем уже сделанные задания:
							таблица цветов и таблица картинок связаны один-ко-многим.
						-->
						<div class="product_colors border_1">
							<a style="background-color: #cc5214;" href="javascript:void(0)" onclick="loadImages(
								this,
								document.getElementById('product_image_1'),
								[
									{thumb: '/images/bananas_red_thumb.jpg', image: '/images/bananas_red.jpg', title: 'Beats PowerBeats 2 (красный) #1'},
									{thumb: '/images/cherry_red_thumb.jpg', image: '/images/cherry_red.jpg', title: 'Beats PowerBeats 2 (красный) #2'},
									{thumb: '/images/walnut_red_thumb.jpg', image: '/images/walnut_red.jpg', title: 'Beats PowerBeats 2 (красный) #3'}
								]
							);"></a>
							<a style="background-color: #d9c700;" href="javascript:void(0)" onclick="loadImages(
								this,
								document.getElementById('product_image_1'),
								[
									{thumb: '/images/bananas_yellow_thumb.jpg', image: '/images/bananas_yellow.jpg', title: 'Beats PowerBeats 2 (жёлтый) #1'},
									{thumb: '/images/cherry_yellow_thumb.jpg', image: '/images/cherry_yellow.jpg', title: 'Beats PowerBeats 2 (жёлтый) #2'},
									{thumb: '/images/walnut_yellow_thumb.jpg', image: '/images/walnut_yellow.jpg', title: 'Beats PowerBeats 2 (жёлтый) #3'}
								]
							);"></a>
							<a style="background-color: #6bb324;" href="javascript:void(0)" onclick="loadImages(
								this,
								document.getElementById('product_image_1'),
								[
									{thumb: '/images/bananas_green_thumb.jpg', image: '/images/bananas_green.jpg', title: 'Beats PowerBeats 2 (зелёный) #1'},
									{thumb: '/images/cherry_green_thumb.jpg', image: '/images/cherry_green.jpg', title: 'Beats PowerBeats 2 (зелёный) #2'},
									{thumb: '/images/walnut_green_thumb.jpg', image: '/images/walnut_green.jpg', title: 'Beats PowerBeats 2 (зелёный) #3'}
								]
							);"></a>
						</div>
						<script id="product_image_1_script" type="text/javascript">
							jQuery(document).ready(function($) {
								loadImages(
									document.getElementById("product_image_1_script").previousElementSibling.children[1],
									document.getElementById('product_image_1'),
									[
										{thumb: '/images/bananas_yellow_thumb.jpg', image: '/images/bananas_yellow.jpg', title: 'Beats PowerBeats 2 (жёлтый) #1'},
										{thumb: '/images/cherry_yellow_thumb.jpg', image: '/images/cherry_yellow.jpg', title: 'Beats PowerBeats 2 (жёлтый) #2'},
										{thumb: '/images/walnut_yellow_thumb.jpg', image: '/images/walnut_yellow.jpg', title: 'Beats PowerBeats 2 (жёлтый) #3'}
									]
								);
							});
						</script>
					</div>
					<div class="block">
						<h3>Характеристики:</h3>
						<p>Вид наушников - вкладыши</p>
						<p>Тип подключение - Bluetooth</p>
						<p>Акустическое оформление - закрытое</p>
						<p>Есть микрофон</p>
						<p>Регулятор громкости</p>
					</div>
					<div class="block">
						<h3 style="text-align: center;">Описание модели:</h3>
						<p>Точная реплика (включая валидность серийного номера) блютуз наушников для спорта Powerbeats 2 Wireless. Спроектированы специалистами компании для абсолютного удобства и комфорта обладателя. Восхитительное звучание, которым могут обладать только беспроводные наушники Beats с глубокими басами и четкими высокими частотами, высокоточное изготовление корпуса наушников, пото- и влагозащита. Ушные дуги имеют специальный запатентованный механизм, облегчающий надевание наушников. Дизайн переключателя громкости оптимизирован для нажатия на бегу. Держа в руках эту модель блутуз наушников, понимаешь, что они, пожалуй, лучшие bluetooth наушники на сегодня. На создание этой серии специалистов Beats и лично Dr.Dre воодушевила блистательная карьера и упорные тренировки баскетболиста LeBron James.</p>
					</div>
				</div>
			</div>
			<div class="margin_bottom_2">
				<h3>Полные технические характеристики:</h3>
				<dl class="columns dltable">
					<div>
						<dt>Сопротивление (impedance)</dt>
						<dd>16 Ω</dd>
					</div>
					<div>
						<dt>Батарея (мАч):</dt>
						<dd>150</dd>
					</div>
					<div>
						<dt>Рабочее расстояние:</dt>
						<dd>до 10 м</dd>
					</div>
					<div>
						<dt>Частотный диапазон:</dt>
						<dd>20 Гц — 20 кГц</dd>
					</div>
					<div>
						<dt>Микрофон:</dt>
						<dd>есть</dd>
					</div>
					<div>
						<dt>Возможность принимать звонки:</dt>
						<dd>имеется</dd>
					</div>
					<div>
						<dt>Время зарядки (ч):</dt>
						<dd>1</dd>
					</div>
					<div>
						<dt>Время в режиме прослушивания музыки (ч):</dt>
						<dd>6</dd>
					</div>
					<div>
						<dt>Время в режиме разговора (ч):</dt>
						<dd>6</dd>
					</div>
					<div>
						<dt>Время в режиме ожидания (ч):</dt>
						<dd>150</dd>
					</div>
					<div>
						<dt>Вес (гр):</dt>
						<dd>24</dd>
					</div>
				</dl>
			</div>
			<div class="columns margin_bottom">
				<div class="block">
					<h3>Преимущества наушников Beats PowerBeats 2 Wireless:</h3>
					<ul>
						<li>Разработаны при участии баскетболиста NBA Леброна Джеймса.</li>
						<li>Фирменное звучание Beats с насыщенными басами.</li>
						<li>Беспроводное подключение к любым аудио устройствам по средствам Bluetooth.</li>
						<li>Регулируемое заушное крепление, позволяющее использовать наушники при занятии спортом.</li>
						<li>Защита наушников от попадания пота и влаги.</li>
						<li>Раздельные динамики для средних и низких частот для качественного звучания.</li>
						<li>Встроенный микрофон.</li>
					</ul>
				</div>
				<div class="block">
					<h3 class="margin_bottom_0">Созданы специально для занятий спортом</h3>
					<p>Наушники PowerBeats 2 подходят для занятия практическим любым видом спорта, включая экстремальные. Регулируемые гибкие душки надежно держат наушники – они не свалится при прыжках, во время бега или от резкого поворота головы.</p>
				</div>
				<div class="block">
					<h3 class="margin_bottom_0">Эксклюзивные технологии Beats для непревзойденного звучания</h3>
					<p>Благодаря технологиям Beats достигается ясный и объемный звук, плотный бас, плавная передача вокала и четкие высокие частоты.</p>
				</div>
				<div class="block">
					<h3 class="margin_bottom_0">Наслаждайтесь музыкой и следите за тем, что происходит вокруг</h3>
					<p>В наушниках PowerBeats 2 вы можете работать, стрелять, бегать в парке или нестись на велосипеде максимально безопасно. Конструкция динамиков позволяет слышать все, что происходит вокруг.</p>
				</div>
				<div class="block">
					<h3 class="margin_bottom_0">Beats PowerBeats работают в любых условиях</h3>
					<p>Прочность и долговечность наушников проверена в самых экстремальных ситуациях. Защита от ультрафиолета позволяет использовать их в самую жаркую погоду.</p>
				</div>
				<div class="block">
					<h3 class="margin_bottom_0">Без проводов и без потерь</h3>
					<p>Благодаря фирменной технологии Beats и последним разработкам в области технологии BlueTooth, наушники PowerBeats 2 Wireless позволяют передавать звук «по воздуху» без потери качества во всем диапазоне.</p>
				</div>
				<div class="block">
					<h3 class="margin_bottom_0">Встроенный микрофон</h3>
					<p>PowerBeats 2 можно использовать в качестве гарнитуры для телефона. Функция ControlTalk позволяет совершать звонки с помощью встроенного микрофона.</p>
				</div>
			</div>
			<div class="margin_bottom_2">
				<h2>Отзывы</h2>
				<div class="comment">
					<div>Анатолий, 19.12.2015
						<span class="rating">
							<span class="star full"></span>
							<span class="star full"></span>
							<span class="star full"></span>
							<span class="star full"></span>
							<span class="star full"></span>
						</span>
					</div>
					<div>Не ожидал что качество будет настолько хорошей для реплики! Спасибо за оперативную доставку! Мои рекомендации!</div>
				</div>
				<div class="comment">
					<div>Мария Сысоева, 1.11.2015
						<span class="rating">
							<span class="star full"></span>
							<span class="star full"></span>
							<span class="star full"></span>
							<span class="star full"></span>
							<span class="star full"></span>
						</span>
					</div>
					<div>Очень стильные и качественные!!звук отменный!!Спасибо за оперативную доставку!</div>
				</div>
			</div>
			<form method="post" action="index.php" class="fieldswidth_100 margin_bottom_2">
				<fieldset>
					<input type="hidden" name="form" value="comment" />
					<h2>Добавить отзыв</h2>
					<p><input name="name" type="text" placeholder="Ваше имя"<?php echo $test_missing['name']; ?> /></p>
					<p>Ваша оценка:
						<a class="rating" href="#">
							<span class="star"></span>
						</a>
						<a class="rating" href="#">
							<span class="star"></span>
							<span class="star"></span>
						</a>
						<a class="rating" href="#">
							<span class="star"></span>
							<span class="star"></span>
							<span class="star"></span>
						</a>
						<a class="rating" href="#">
							<span class="star"></span>
							<span class="star"></span>
							<span class="star"></span>
							<span class="star"></span>
						</a>
						<a class="rating" href="#">
							<span class="star"></span>
							<span class="star"></span>
							<span class="star"></span>
							<span class="star"></span>
							<span class="star"></span>
						</a>
					</p>
					<p><textarea name="comment" rows="10" placeholder="Ваш отзыв"<?php echo $test_missing['comment']; ?>></textarea></p>
					<input type="submit" value="Добавить отзыв" />
				</fieldset>
			</form>
			<form id="testform" method="post" action="index.php#testform" class="wizard tabledlabels fieldswidth_100">
				<fieldset class="margin_bottom_2">
					<input type="hidden" name="form" value="test" />
					<h2>Тестовая форма</h2>
					<?php if($status == 2) {echo '<p class="red">Заполнены не все необходимые поля (помечены красным).</p>';} ?>
					<label>
						<span>ФИО</span>
						<span>
							<span><input name="fio" type="text" placeholder="Введите ФИО"<?php echo $test_missing['fio']; ?> /></span>
							<span>Да, нужно ввести ФИО</span>
						</span>
					</label>
					<label>
						<span>Телефон</span>
						<span>
							<span><input name="phone" type="text" placeholder="+7 903 999 99 99"<?php echo $test_missing['phone']; ?> /></span>
							<span>А сюда нужно ввести телефон</span>
						</span>
					</label>
					<label>
						<span>Ваш e-mail <b class="red">*</b></span>
						<span>
							<span><input name="email" type="text" placeholder="test@example.ru"<?php echo $test_missing['email']; ?> /></span>
							<span>Внимание! Введя электронную почту, к которой у Вас нет доступа, вы не сможете подтвердить заказ.</span>
						</span>
					</label>
					<label>
						<span>Укажите дополнительную информацию <b class="red">*</b></span>
						<span>
							<span><textarea name="info" rows="4" placeholder="Введите сюда то, с чем, вы считаете, нам необходимо ознакомиться"<?php echo $test_missing['info']; ?>></textarea></span>
							<span></span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><textarea name="advanced" rows="4" placeholder="Этот текст является примером некоторого информационного наполнения, созданного с неопределённой на момент написания этого текста целью. Неопределённость этой цели, однако, не говорит о том, что этой цели не появится в будущем, как не говорит и о том, что составитель этого текста безумен, либо лишён своих собственных целей и задач в условиях глобальных проблем занятости в современном мире. Напротив, сиюминутная неопределённость цели этой информации предполагает возможную в будущем потребность в некоторой бессмысленной, максимально абстрагированной информации. Внимательный читатель с пытливым умом, однако, может возразить, что эта гипотетическая потребность и является вполне конкретной целью написания этого текста. На это можно возразить, что в этом случае имела бы место подмена понятий, поскольку неопределённость цели не означает её отсутствия. Итак, специфика данного текста предполагает его минимальную осмысленность, что продиктовано его целями и задачами, на данный момент неопределёнными, но безусловно существующими. Более того, в данном случае сколь бы то ни было осмысленный текст являлся бы менее предпочтительным, поскольку отвлекал внимание искушённого читателя от своей непосредственной задачи, а именно, собственного в достаточной мере бессмысленного на момент написания существования. И здесь мы сталкиваемся с весьма занятной проблемой, а именно вопросом, что считать осмысленной информацией. Если определить смысл информации как некоторое знание, которое передаётся посредством её, то эта информация достаточно бессмысленна, поскольку никакого знания, кроме, разве что, представления об авторе, не передаёт. С другой стороны, смысл информации можно определить как некоторый, пусть и бесполезный, но связный и законченный посыл, а он-то как раз в этом тексте существует и заключается в рассуждениях и выводах о себе самом, то есть, целях и задачах этой информации. Таким образом, вопрос о достаточности осмысленности этого текста осложняется не только неопределённостью, собственно, достаточности, но также, в данном случае, и неопределённостью осмысленности как таковой. В связи со всем вышесказанным можно заключить, что давно пора бы всё это дело заключить."<?php echo $test_missing['advanced']; ?>></textarea></span>
							<span>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?</span>
						</span>
					</label>
					<span class="tabledlabel margin_bottom_2">
						<span>Quo vadis?</span>
						<span>
							<span>
								<span<?php echo $test_missing['vadis']; ?> style="display: inline-block;">
									<label><input name="vadis" type="radio" value="Veni" checked /> Veni</label><br />
									<label><input name="vadis" type="radio" value="Vidi" /> Vidi</label><br />
									<label><input name="vadis" type="radio" value="Vici" /> Vici</label><br />
									<label><input name="vadis" type="radio" value="Errare Humanum est" /> Errare Humanum est</label>
								</span><br /><br />
								<label><input name="rerum" type="checkbox" value="Rerum" checked /> Temporibus autem quibusdam et aut officiis debitis aut rerum</label>
							</span>
							<span></span>
						</span>
					</span>
				</fieldset>
				<fieldset class="margin_bottom_2">
					<legend class="margin_bottom">Выбор доставки</legend>
					<label><b<?php echo $test_missing['delivery']; ?>><input id="delivery_courier" name="delivery" type="radio" value="courier" onchange="showDelivery();" /></b> Курьером</label><br />
					<label><b<?php echo $test_missing['delivery']; ?>><input id="delivery_pickup" name="delivery" type="radio" value="pickup" onchange="showDelivery();" /></b> Самовывоз</label>
				</fieldset>
				<fieldset id="delivery_courier_fieldset" class="margin_bottom_2">
					<legend class="margin_bottom">Доставка курьером</legend>
					<label>
						<span><b class="red">*</b></span>
						<span>
							<span><input name="street" type="text" placeholder="Улица"<?php echo $test_missing['street']; ?> /></span>
						</span>
					</label>
					<label>
						<span><b class="red">*</b></span>
						<span>
							<span><input name="house" type="text" placeholder="Дом"<?php echo $test_missing['house']; ?> /></span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><input name="entrance" type="text" placeholder="Подъезд"<?php echo $test_missing['entrance']; ?> /></span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><input name="intercom" type="text" placeholder="Домофон"<?php echo $test_missing['intercom']; ?> /></span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><input name="floor" type="text" placeholder="Этаж"<?php echo $test_missing['floor']; ?> /></span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><input name="flat" type="text" placeholder="Квартира"<?php echo $test_missing['flat']; ?> /></span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><input name="building" type="text" placeholder="Корпус или строение"<?php echo $test_missing['building']; ?> /></span>
							<span>(если есть)</span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><textarea name="latin_c" rows="4" placeholder="Вы удивлены, почему часть анкеты написана на латыни?"<?php echo $test_missing['latin_c']; ?>></textarea></span>
						</span>
					</label>
				</fieldset>
				<fieldset id="delivery_pickup_fieldset" class="margin_bottom_2">
					<legend class="margin_bottom">Самовывоз заказа</legend>
					<label>
						<span></span>
						<span>
							<span>
								<span class="selectspan">
									<select name="point"<?php echo $test_missing['point']; ?>>
										<?php
										$points = $conn->query("SELECT * FROM `points`");
										foreach($points as $row) {
											echo '<option value="' . $row['id'] . '">' . $row['title'] . '</option>';
										}
										?>
									</select>
								</span>
							</span>
						</span>
					</label>
					<label>
						<span></span>
						<span>
							<span><textarea name="latin_p" rows="4" placeholder="Вы удивлены, почему часть анкеты написана на латыни?"<?php echo $test_missing['latin_p']; ?>></textarea></span>
						</span>
					</label>
				</fieldset>
				<div class="wizard_submit">
					<input type="submit" value="Вперёд →" class="button" />
				</div>
			</form>
		</main>
	</div>
</body>
</html>
<?php
	$conn = null;
?>
