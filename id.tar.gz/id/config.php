<?php
$db = array(
	'name' => 'db_naushniki',
	'username' => 'dbu_id',
	'password' => 'L+$12j%5N}',
	'host' => 'localhost',
	'port' => '3306',
	'driver' => 'mysql',
	'collation' => 'utf8_general_ci',
);
?>
